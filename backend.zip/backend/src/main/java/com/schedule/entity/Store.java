package com.schedule.entity;

import lombok.Data;

@Data
public class Store {
    private String storeId;
    private String storeName;
    private String address;
    private float size;
}
