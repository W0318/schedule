package com.schedule.entity;

import lombok.Data;

@Data
public class Worktime {
    private String worktimeId;
    private String employeeId;
}
